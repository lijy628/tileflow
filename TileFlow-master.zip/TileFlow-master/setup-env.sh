export PATH=$(pwd)/build/bin:$PATH
export PATH=$(pwd)/3rdparty/timeloop/bin:$PATH