#include "tileflow/common.hpp"


namespace TileFlow {

int verbose_level = 0;

config::CompoundConfigNode macros;

} // namespace TileFlow