## Attention Experiments 

Write architectures, mappings, problems in arch/, map-raw/, prob/, run experiments by

```
python ./script.py 
```